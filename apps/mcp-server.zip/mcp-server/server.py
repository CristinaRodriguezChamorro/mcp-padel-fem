from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastmcp import FastMCP
from tools.news import get_latest_news
from tools.db import init_db
import os

# Inicializar BD
init_db()

app = FastAPI(title="Padel Fem MCP")

mcp = FastMCP("PadelFemMCP")

@app.get("/api/news")
async def news():
    return await get_latest_news()

@mcp.tool()
async def latest_news_tool():
    """Obtiene las últimas noticias de pádel femenino"""
    return await get_latest_news()

# Servir la web
@app.get("/")
async def serve_index():
    return FileResponse("static/index.html", media_type="text/html")

# Montar carpeta static para archivos estáticos
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
