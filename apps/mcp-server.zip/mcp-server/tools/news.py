import feedparser

RSS_FEEDS = [
    "https://e00-marca.uecdn.es/rss/padel.xml",
    "https://www.mundodeportivo.com/rss/padel.xml"
]

# Palabras clave que indican pádel femenino
FEMALE_KEYWORDS = [
    "paula", "josemaría", "gemma", "triay", "bea", "gonzález", 
    "ariana", "sanchez", "majo", "gonzalez", "aránzazu", "osoro",
    "belén", "angulo", "alba", "heredia", "patricia", "llaguno",
    "patri", "clemente", "marta", "ortega", "elena", "rubio",
    "cristina", "mendoza", "femenino", "mujer", "damas",
    "women", "female", "wta", "padelwta", "femenil"
]

# Palabras que excluyen (varones conocidos)
MALE_KEYWORDS = [
    "lebron", "galan", "chingotto", "tapia", "coello", 
    "paquito", "navarro", "lamperti", "capra", "campoy",
    "juan martin", "diaz", "beltran", "rafa", "nadal",
    "paquito navarro", "fernando", "belasteguin", "sanyo",
    "varones", "hombres", "men", "male", "masculino"
]

async def get_latest_news():
    news = []

    for url in RSS_FEEDS:
        feed = feedparser.parse(url)

        for entry in feed.entries[:15]:  # Busca en más noticias para filtrar
            title = entry.get("title", "").lower()
            
            # Filtro 1: Debe contener al menos una palabra clave femenina
            has_female_keyword = any(keyword in title for keyword in FEMALE_KEYWORDS)
            
            # Filtro 2: No debe contener palabras de jugadores varones
            has_male_keyword = any(keyword in title for keyword in MALE_KEYWORDS)
            
            # Aceptar si tiene palabra femenina Y no tiene palabra masculina
            if has_female_keyword and not has_male_keyword:
                news.append({
                    "title": entry.get("title"),
                    "link": entry.get("link"),
                    "published": entry.get("published", "")
                })
            
            # Limitar a 5 noticias
            if len(news) >= 5:
                break

    return news
