import requests
from bs4 import BeautifulSoup
import asyncio
from datetime import datetime

async def scrape_calendar():
    """Scraping en tiempo real del calendario de Premier Padel desde padelfip.com"""
    try:
        url = "https://www.padelfip.com/es/calendario-premier-padel/?events-year=2026"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        
        events = []
        
        # Buscar eventos del calendario
        event_rows = soup.find_all('div', class_='row event-tournament')
        
        if event_rows:
            for row in event_rows[:10]:  # Primeros 10 eventos
                try:
                    # Extraer fecha
                    date_elem = row.find('div', class_='event-date')
                    date_text = date_elem.text.strip() if date_elem else "Sin fecha"
                    
                    # Extraer nombre del torneo
                    title_elem = row.find('h3') or row.find('h4')
                    title_text = title_elem.text.strip() if title_elem else "Sin nombre"
                    
                    # Extraer ubicación
                    location_elem = row.find('div', class_='event-location') or row.find('span', class_='location')
                    location_text = location_elem.text.strip() if location_elem else "Sin ubicación"
                    
                    # Extraer link si existe
                    link_elem = row.find('a', href=True)
                    link = link_elem['href'] if link_elem else "#"
                    
                    events.append({
                        "date": date_text,
                        "tournament": title_text,
                        "location": location_text,
                        "link": link,
                        "source": "padelfip.com",
                        "updated": datetime.now().isoformat()
                    })
                except Exception as e:
                    print(f"Error extrayendo evento: {e}")
                    continue
        
        return events if events else None
        
    except Exception as e:
        print(f"Error scraping calendar: {e}")
        return None


async def scrape_rankings():
    """Fallback vacío"""
    return None

async def scrape_results():
    """Fallback vacío"""
    return None
