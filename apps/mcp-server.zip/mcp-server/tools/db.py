from sqlalchemy import create_engine, Column, Integer, String, DateTime, JSON, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import os

DATABASE_URL = "postgresql://padel:padel@postgres:5432/padel"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class CachedRanking(Base):
    __tablename__ = "cached_rankings"
    
    id = Column(Integer, primary_key=True, index=True)
    rank = Column(Integer)
    name = Column(String)
    points = Column(String)
    source = Column(String)
    updated = Column(DateTime, default=datetime.now)
    data = Column(JSON)


class CachedMatch(Base):
    __tablename__ = "cached_matches"
    
    id = Column(Integer, primary_key=True, index=True)
    tournament = Column(String)
    date = Column(String)
    team1 = Column(String)
    team2 = Column(String)
    score = Column(String)
    source = Column(String)
    updated = Column(DateTime, default=datetime.now)
    data = Column(JSON)


def init_db():
    """Inicializa las tablas si no existen"""
    try:
        Base.metadata.create_all(bind=engine)
    except Exception as e:
        print(f"Error inicializando DB: {e}")


def save_rankings(rankings_list):
    """Guarda rankings en la BD"""
    try:
        db = SessionLocal()
        db.query(CachedRanking).delete()
        
        for ranking in rankings_list:
            db_ranking = CachedRanking(
                rank=ranking.get("rank"),
                name=ranking.get("name"),
                points=ranking.get("points"),
                source=ranking.get("source"),
                data=ranking
            )
            db.add(db_ranking)
        
        db.commit()
        db.close()
        return True
    except Exception as e:
        print(f"Error guardando rankings: {e}")
        return False


def get_cached_rankings():
    """Obtiene últimos rankings guardados"""
    try:
        db = SessionLocal()
        rankings = db.query(CachedRanking).order_by(CachedRanking.rank).all()
        db.close()
        
        if rankings:
            return [r.data for r in rankings]
        return None
    except Exception as e:
        print(f"Error leyendo rankings: {e}")
        return None


def save_matches(matches_list):
    """Guarda matches en la BD"""
    try:
        db = SessionLocal()
        db.query(CachedMatch).delete()
        
        for match in matches_list:
            db_match = CachedMatch(
                tournament=match.get("tournament"),
                date=match.get("date"),
                team1=match.get("team1"),
                team2=match.get("team2"),
                score=match.get("score"),
                source=match.get("source"),
                data=match
            )
            db.add(db_match)
        
        db.commit()
        db.close()
        return True
    except Exception as e:
        print(f"Error guardando matches: {e}")
        return False


def get_cached_matches():
    """Obtiene últimos matches guardados"""
    try:
        db = SessionLocal()
        matches = db.query(CachedMatch).order_by(CachedMatch.updated.desc()).all()
        db.close()
        
        if matches:
            return [m.data for m in matches]
        return None
    except Exception as e:
        print(f"Error leyendo matches: {e}")
        return None
