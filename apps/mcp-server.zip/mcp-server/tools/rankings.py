from .scraper import scrape_calendar
from .db import save_matches, get_cached_matches

async def get_rankings():
    """Retorna mensaje de que no hay API pública"""
    return {
        "error": "No disponible",
        "message": "No hay API pública de rankings disponible. Los datos de FIP están protegidos.",
        "source": "padelfip.com"
    }


async def get_recent_matches():
    """Retorna calendario de torneos desde padelfip.com"""
    
    # Intenta scraping del calendario
    live_calendar = await scrape_calendar()
    
    if live_calendar and len(live_calendar) > 0:
        # Guarda en BD para futuro uso
        save_matches(live_calendar)
        return live_calendar
    
    # Si falla el scraping, intenta obtener últimos datos guardados
    cached_matches = get_cached_matches()
    
    if cached_matches:
        return cached_matches
    
    # Si no hay nada, devuelve error
    return {
        "error": "No se pudieron obtener eventos",
        "details": "El scraper falló y no hay datos en caché",
        "source": "padelfip.com"
    }
